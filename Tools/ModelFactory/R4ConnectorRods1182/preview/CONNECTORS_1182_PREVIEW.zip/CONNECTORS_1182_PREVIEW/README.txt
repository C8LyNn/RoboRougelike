Podgląd #1182: otwórz index.html w przeglądarce (działa offline z pliku, three.js r128 w lib/).
Modele to prawdziwe GLB z Tools/ModelFactory/R4ConnectorRods1182 (łączniki i konstrukcje z wcześniejszymi modelami).
